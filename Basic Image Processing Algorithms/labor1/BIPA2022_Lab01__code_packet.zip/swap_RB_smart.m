function [BGR] = swap_RB_smart(RGB)
    
end