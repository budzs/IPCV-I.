function ClassMap = recognition_phase(I, MODEL)
    
end
