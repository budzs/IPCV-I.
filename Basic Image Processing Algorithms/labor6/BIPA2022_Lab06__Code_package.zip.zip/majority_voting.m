function OUT = majority_voting(IN, w_dia)
    
end
