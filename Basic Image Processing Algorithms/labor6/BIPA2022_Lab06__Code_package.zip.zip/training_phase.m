function MODEL = training_phase(T_cell)
    
end
