function H = laws_kernel(k)
    
end
