function newF = mask_fourier(F, x, y, r)
    
end
