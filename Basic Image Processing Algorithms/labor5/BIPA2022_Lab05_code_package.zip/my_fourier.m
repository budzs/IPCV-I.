function [F] = my_fourier(I)
    
end
