function [P, M] = fourier_parts(F)
    
end
